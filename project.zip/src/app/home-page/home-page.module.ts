import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HomePageRoutingModule } from "./home-page-routing.module";
import { HomePageComponent } from "./home-page.component";
import {InputTextareaModule} from 'primeng/inputtextarea';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {TooltipModule} from 'primeng/tooltip';
import { TextInputAutocompleteModule } from "angular-text-input-autocomplete";
import { BrowserModule } from "@angular/platform-browser";
@NgModule({
    imports: [
        CommonModule,
        HomePageRoutingModule,
        FormsModule,
        InputTextareaModule,
        AutoCompleteModule,
        TooltipModule,
        TextInputAutocompleteModule,
        
    ],
    declarations: [HomePageComponent],
  providers: [],
  
})
export class HomePageModule { }
