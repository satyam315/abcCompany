import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map} from 'rxjs/operators';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  constructor() { }
  formControlValue:string;
  ngOnInit() {
  }

  findChoices(searchText: string) {
    let nameData=['Gina Williams','Jake Williams','Jamie John','Jeff Stewart','John Doe','Paula M .Keith']
    return nameData
      .filter(item => item.toLowerCase().includes(searchText.toLowerCase()))
      .slice(0, 5);
  }

  getChoiceLabel(choice: string) {
    return `@${choice} `;
  }
}
