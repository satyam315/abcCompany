import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService, SelectItem } from 'primeng/api';
import { first } from 'rxjs/operators';
import { UserService } from '../service/userservice';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userform: FormGroup;

  submitted: boolean;

  genders: SelectItem[];

  description: string;
  
  userData=[];

  constructor(
    private fb: FormBuilder, 
    private messageService: MessageService,
    private userService:UserService,
    private router:Router
    ) {}

  ngOnInit() {
      this.userform = this.fb.group({
          'userId': new FormControl('', Validators.required),
          'password': new FormControl('', Validators.compose([Validators.required, Validators.minLength(6)]))
      });
      this.userService.getUserData().then(data=>{
        this.userData=data;
        
      })
  }

  onSubmit(value) {
    for(let i=0; i<this.userData.length; i++){
      if(value.userId == this.userData[i].userid && value.password == this.userData[i].password){
        let userData=this.userData[i].username

        localStorage.setItem('User',userData);
        this.submitted = true;
        if(userData){
          setTimeout(() => {
             window.location.reload();
             this.router.navigate(['/home-page'])
          }, 2000);
        }
        return value;
        
      }
     
    }
  
    
      
  }

  get diagnostic() { return JSON.stringify(this.userform.value); }

}
