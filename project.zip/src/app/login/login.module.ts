import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { LoginRoutingModule } from "./login-routing.module";
import { LoginComponent } from "./login.component";
import { ReactiveFormsModule } from '@angular/forms';
// import {PasswordModule} from 'primeng/password';
import {ToastModule} from 'primeng/toast';
import {PanelModule} from 'primeng/panel';
import {ButtonModule} from 'primeng/button';
import { MessageService } from 'primeng/api';
@NgModule({
    imports: [
        CommonModule,
        LoginRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        // PasswordModule,
        ButtonModule,
        PanelModule,
        ToastModule
      ],
    declarations: [LoginComponent],
  providers: [MessageService],
  
})
export class LoginModule { }
