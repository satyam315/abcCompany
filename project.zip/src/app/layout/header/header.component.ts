import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(private router:Router) { }
  User:any;
  roleAccess:boolean;
  userLoggedIN:boolean=true;
  userLoggedOut:boolean;

  ngOnInit(): void {
      this.User=localStorage.getItem('User');
      if(this.User !=='' && this.User!== undefined && this.User !== null){
        this.userLoggedIN=false;
        this.userLoggedOut=true;
        this.roleAccess=true;
      }
  }

  deleteStoredData(){
    localStorage.removeItem('User');
    this.userLoggedOut=false;
    this.userLoggedIN=true;
    this.roleAccess=false;
    window.location.reload();
    this.router.navigate(['/home-page']);
  }
}
