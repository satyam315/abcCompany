import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AuthGuard} from "../Guard/auth-guard.guard";
import { LoginGuard } from "../Guard/login-guard.guard";
import { HomePageComponent } from "../home-page/home-page.component";
import { LayoutComponent } from "./layout.component";
const routes: Routes = [
    {
      path: '',
      component: LayoutComponent,
    
    children: [
      { path: '', redirectTo: 'home-page', pathMatch: 'prefix' },
      
      {
        path: 'gallery',
        loadChildren: () => import('../gallery/gallery.module')
                        .then(m => m.GalleryModule),
                          canActivate:[AuthGuard]
      },
      {
        path: 'login',
        loadChildren: () => import('../login/login.module')
                        .then(m => m.LoginModule),
                          canActivate:[LoginGuard]
      },
      {
        path: 'home-page',
        loadChildren: () => import('../home-page/home-page.module')
                        .then(m => m.HomePageModule)
      },
      {
        path: 'about-page',
        loadChildren: () => import('../about-page/about-page.module')
                        .then(m => m.AboutPageModule)
      }
    ]
    }
  ];
  
  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]  
  })
  export class LayoutRoutingModule {
  }