import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

    constructor(private http: HttpClient) { }

    getUserData() {
    return this.http.get<any>('assets/user.json')
      .toPromise()
      .then(res => <any[]>res.data)
      .then(data => { return data; });
    }
}