import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GalleryService {

    constructor(private http: HttpClient) { }

    getImageData() {
      return this.http.get<any>('assets/photos.json')
      .toPromise()
      .then(res => <any[]>res.data)
      .then(data => { return data; });
    }
}