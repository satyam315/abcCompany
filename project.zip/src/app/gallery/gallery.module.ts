import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { GalleryRoutingModule } from "./gallery-routing.module";
import { GalleryComponent } from "./gallery.component";
import { GalleriaModule } from 'primeng/galleria';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        GalleryRoutingModule,
        GalleriaModule
      ],
    declarations: [GalleryComponent],
  providers: [],
  
})
export class GalleryModule { }
